package com.dynamicpill.module;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/**
 * Hides the duplicate stock Control Center tiles (Wi-Fi, Mobile data, Bluetooth, Hotspot/link)
 * from the tile grid. A tile is recognised by its contentDescription, view id, class name or the
 * tile spec stored inside it. Which tiles are hidden: the EXACT / PART lists below (one place).
 */
final class DupTileHider {
    private static final int KEY_HIDE = 0x7e0b0101;   // marker: "keep this view GONE"

    // whole name / spec must equal one of these
    private static final String[] EXACT = {
            "wifi", "wi-fi", "cell", "data", "mobiledata", "bt", "bluetooth", "hotspot"};
    // name contains one of these
    private static final String[] PART = {
            "wi-fi", "wifi", "wlan", "mobile data", "mobile network", "cellular",
            "bluetooth", "hotspot", "tether"};
    private static final String[] GETTERS = {"getTileSpec", "getSpec", "getTileKey", "getKey"};

    private static boolean hooked;
    private static final Map<View, Boolean> ROOTS =
            Collections.synchronizedMap(new WeakHashMap<View, Boolean>());

    private DupTileHider() { }

    /** Keeps hidden tiles GONE even when System UI tries to show them again. */
    static synchronized void install() {
        if (hooked) return;
        hooked = true;
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                View v = (View) param.thisObject;
                if (v.getTag(KEY_HIDE) != null) param.args[0] = View.GONE;
            }
        });
    }

    /** Called for every Control Center view that attaches; watches its window once. */
    static void onAttach(View v) {
        try {
            View root = v.getRootView();
            if (root == null || ROOTS.containsKey(root)) return;
            ROOTS.put(root, Boolean.TRUE);
            Watcher w = new Watcher(root);
            root.getViewTreeObserver().addOnGlobalLayoutListener(w);
        } catch (Throwable t) {
            XposedBridge.log("DynamicPill: DupTileHider attach failed: " + t);
        }
    }

    private static final class Watcher implements ViewTreeObserver.OnGlobalLayoutListener, Runnable {
        private final WeakReference<View> rootRef;
        private final Map<View, String> seen = new WeakHashMap<>();
        private boolean pending;
        private int logged;

        Watcher(View root) { rootRef = new WeakReference<>(root); }

        @Override public void onGlobalLayout() {
            View root = rootRef.get();
            if (root == null || pending) return;
            pending = true;
            root.postDelayed(this, 300);
        }

        @Override public void run() {
            pending = false;
            View root = rootRef.get();
            if (root == null) return;
            try {
                if (!root.isAttachedToWindow()) {
                    ViewTreeObserver o = root.getViewTreeObserver();
                    if (o.isAlive()) o.removeOnGlobalLayoutListener(this);
                    ROOTS.remove(root);
                    return;
                }
                scan(root);
            } catch (Throwable t) {
                XposedBridge.log("DynamicPill: DupTileHider scan failed: " + t);
            }
        }

        private int dp(View v, float x) {
            return Math.round(x * v.getResources().getDisplayMetrics().density);
        }

        private void scan(View v) {
            if (v.getTag(KEY_HIDE) != null || v.getVisibility() == View.GONE) return;
            if (examine(v)) return;
            if (v instanceof ViewGroup) {
                ViewGroup g = (ViewGroup) v;
                for (int i = 0; i < g.getChildCount(); i++) scan(g.getChildAt(i));
            }
        }

        private boolean examine(View v) {
            int w = v.getWidth(), h = v.getHeight();
            CharSequence cd = v.getContentDescription();
            String sig = (cd == null ? "" : cd.toString()) + "|" + w + "x" + h;
            if (sig.equals(seen.get(v))) return false;
            seen.put(v, sig);

            boolean tileSized = w >= dp(v, 40) && h >= dp(v, 40) && w <= dp(v, 130) && h <= dp(v, 130);
            List<String> keys = new ArrayList<>();
            if (cd != null) keys.add(cd.toString());
            if (v.getId() != View.NO_ID && (v.getId() >>> 24) != 0) {
                try { keys.add(v.getResources().getResourceEntryName(v.getId())); } catch (Throwable ignored) { }
            }
            if (v.getTag() instanceof String) keys.add((String) v.getTag());
            keys.add(v.getClass().getSimpleName());
            if (tileSized) reflectKeys(v, keys);

            String hit = null;
            for (String k : keys) {
                hit = match(k);
                if (hit != null) break;
            }
            if (hit == null) {
                if (tileSized && logged < 40) {
                    logged++;
                    XposedBridge.log("DynamicPill: tile candidate " + v.getClass().getName()
                            + " " + w + "x" + h + " keys=" + keys);
                }
                return false;
            }
            return hide(v, hit);
        }

        private boolean hide(View m, String why) {
            View t = m;
            int min = dp(m, 40);
            while ((t.getWidth() < min || t.getHeight() < min) && t.getParent() instanceof ViewGroup) {
                t = (View) t.getParent();
            }
            int w = t.getWidth(), h = t.getHeight();
            if (w < min || h < min || w > dp(t, 130) || h > dp(t, 130)) return false;
            float ar = (float) w / h;
            if (ar < 0.6f || ar > 1.6f) return false;
            int[] l = new int[2];
            t.getLocationOnScreen(l);
            if (l[1] < dp(t, 90)) return false;          // header icons (top of the panel) stay
            t.setTag(KEY_HIDE, Boolean.TRUE);
            t.setVisibility(View.GONE);
            XposedBridge.log("DynamicPill: duplicate tile hidden '" + why + "' "
                    + t.getClass().getName() + " " + w + "x" + h);
            return true;
        }

        private void reflectKeys(View v, List<String> keys) {
            int n = 0;
            for (Class<?> k = v.getClass();
                 k != null && k != Object.class && !k.getName().startsWith("android.");
                 k = k.getSuperclass()) {
                for (Field f : k.getDeclaredFields()) {
                    if (++n > 60) return;
                    if (Modifier.isStatic(f.getModifiers())) continue;
                    try {
                        f.setAccessible(true);
                        Object o = f.get(v);
                        if (o == null || o instanceof View || o instanceof Context) continue;
                        if (o instanceof CharSequence) { keys.add(o.toString()); continue; }
                        String tn = o.getClass().getName();
                        if (tn.startsWith("java.") || tn.startsWith("android.")) continue;
                        String s = specOf(o);
                        if (s != null) keys.add(s);
                    } catch (Throwable ignored) { }
                }
            }
        }
    }

    private static String match(String k) {
        if (k == null || k.length() > 64) return null;
        String s = k.toLowerCase();
        if (s.contains("saver") || s.contains("setting")) return null;
        for (String e : EXACT) if (s.equals(e)) return e;
        for (String p : PART) if (s.contains(p)) return p;
        return null;
    }

    private static String specOf(Object o) {
        for (String g : GETTERS) {
            try {
                Method m = o.getClass().getMethod(g);
                Object r = m.invoke(o);
                if (r instanceof CharSequence) return r.toString();
            } catch (Throwable ignored) { }
        }
        return null;
    }
}
