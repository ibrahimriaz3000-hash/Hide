package com.dynamicpill.module;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** iOS style settings screen. Values are read live by System UI (under a second). */
public class MainActivity extends Activity {
    private static final int BLUE = 0xFF2979FF;
    private static final int GREEN = 0xFF34C759;
    private static final int GRAY = 0xFF8E8E93;
    // light / dark follow the system setting
    private boolean night;
    private int BG, CARD, TEXT, DIVIDER, TRACK;
    private static final int UNIT_MM = 0, UNIT_PCT = 1;

    private SharedPreferences sp;

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @SuppressWarnings({"deprecation", "WorldReadableFiles"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        night = (getResources().getConfiguration().uiMode
                & android.content.res.Configuration.UI_MODE_NIGHT_MASK)
                == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        BG = night ? 0xFF000000 : 0xFFF2F2F7;
        CARD = night ? 0xFF1C1C1E : 0xFFFFFFFF;
        TEXT = night ? 0xFFFFFFFF : 0xFF000000;
        DIVIDER = night ? 0xFF38383A : 0xFFE5E5EA;
        TRACK = night ? 0xFF363636 : 0xFFE5E5EA;
        try {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_WORLD_READABLE);
        } catch (Throwable t) {
            sp = getSharedPreferences(PillController.PREF_FILE, Context.MODE_PRIVATE);
            Toast.makeText(this, "Activate the module in LSPosed first", Toast.LENGTH_LONG).show();
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(48), dp(16), dp(32));

        TextView title = new TextView(this);
        title.setText("Dynamic Pill");
        title.setTextSize(34);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(TEXT);
        title.setPadding(dp(4), 0, 0, dp(4));
        root.addView(title);

        // ---- Pill
        LinearLayout pill = section(root, "PILL");
        switchRow(pill, "Show pill", PillController.K_ENABLED, true);
        switchRow(pill, "Show on lock screen", PillController.K_LOCK, true);
        sliderRow(pill, "Width", PillController.K_WIDTH, PillController.D_WIDTH, 40, 300, 0, UNIT_MM);
        sliderRow(pill, "Height", PillController.K_HEIGHT, PillController.D_HEIGHT, 20, 120, 0, UNIT_MM);
        sliderRow(pill, "Vertical offset", PillController.K_YOFF, PillController.D_YOFF, 0, 200, -100, UNIT_MM);
        sliderRow(pill, "Opacity", PillController.K_ALPHA, 100, 0, 100, 0, UNIT_PCT);
        sliderRow(pill, "White border (0 = off)", PillController.K_BORDER, 4, 0, 20, 0, UNIT_MM);

        // ---- Indicators
        LinearLayout ind = section(root, "INDICATORS (INSIDE THE PILL)");
        switchRow(ind, "Yellow dot (always on)", PillController.K_IND_DOT, true);
        switchRow(ind, "Dot turns green in WhatsApp", PillController.K_IND_WA, true);
        switchRow(ind, "Call: green blinking outline", PillController.K_IND_CALL, true);
        switchRow(ind, "Charging: green bolt icon", PillController.K_IND_CHARGE, true);
        switchRow(ind, "Blink dot every 15 s while a notification is waiting", PillController.K_IND_NOTIF, true);

        // ---- Line
        LinearLayout line = section(root, "LINE (iOS GRABBER)");
        switchRow(line, "Show line", PillController.K_LINE_ON, true);
        sliderRow(line, "Width", PillController.K_LINE_W, PillController.D_LINE_W, 30, 600, 0, UNIT_MM);
        sliderRow(line, "Thickness", PillController.K_LINE_H, 6, 2, 30, 0, UNIT_MM);
        sliderRow(line, "Center from right edge", PillController.K_LINE_X, PillController.D_LINE_X, 0, 700, 0, UNIT_MM);
        sliderRow(line, "Distance from top", PillController.K_LINE_Y, PillController.D_LINE_Y, 0, 300, 0, UNIT_MM);
        sliderRow(line, "Opacity", PillController.K_LINE_ALPHA, 70, 5, 100, 0, UNIT_PCT);

        // ---- Status bar padding
        LinearLayout bar = section(root, "STATUS BAR PADDING");
        sliderRow(bar, "Left", PillController.K_PAD_L, 0, 0, 200, 0, UNIT_MM);
        sliderRow(bar, "Right", PillController.K_PAD_R, 0, 0, 200, 0, UNIT_MM);
        sliderRow(bar, "Top", PillController.K_PAD_T, 0, 0, 200, 0, UNIT_MM);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(sv);
    }

    private LinearLayout section(LinearLayout root, String name) {
        TextView h = new TextView(this);
        h.setText(name);
        h.setTextSize(12);
        h.setTextColor(GRAY);
        h.setPadding(dp(16), dp(20), 0, dp(6));
        root.addView(h);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD);
        g.setCornerRadius(dp(12));
        card.setBackground(g);
        root.addView(card, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    private void divider(LinearLayout card) {
        if (card.getChildCount() == 0) return;
        View d = new View(this);
        d.setBackgroundColor(DIVIDER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 1);
        lp.leftMargin = dp(16);
        card.addView(d, lp);
    }

    private void switchRow(LinearLayout card, String name, final String key, boolean def) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(10));

        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        IosSwitch sw = new IosSwitch(this, TRACK, GREEN);
        sw.snap(sp.getBoolean(key, def));
        sw.setListener(on -> sp.edit().putBoolean(key, on).apply());
        row.addView(sw);
        card.addView(row);
    }

    /** value = progress + min + shift; mm sliders store 0.1 mm units. */
    private void sliderRow(LinearLayout card, final String name, final String key, int def,
                           final int min, int max, final int shift, final int unit) {
        divider(card);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(dp(16), dp(10), dp(16), dp(6));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView t = new TextView(this);
        t.setText(name);
        t.setTextSize(16);
        t.setTextColor(TEXT);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = new TextView(this);
        val.setTextSize(15);
        val.setTextColor(GRAY);
        top.addView(val);
        row.addView(top);

        int cur = sp.getInt(key, def);
        val.setText(fmt(cur, unit));

        final FillSlider bar = new FillSlider(this, TRACK, BLUE);
        bar.setMax(max - min);
        bar.setProgress(cur - shift - min);
        bar.setListener((p, user) -> {
            int v = p + min + shift;
            val.setText(fmt(v, unit));
            if (user) sp.edit().putInt(key, v).apply();
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(28));
        blp.topMargin = dp(10);
        blp.bottomMargin = dp(8);
        row.addView(bar, blp);
        card.addView(row);
    }

    private String fmt(int v, int unit) {
        return unit == UNIT_PCT ? v + " %" : (v / 10f) + " mm";
    }
}
